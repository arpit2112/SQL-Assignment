**First**

Select * from Customer Where Country = 'Germany'

-------------------------------------------------------------------------------------
**Second**

Select Firstname+' '+LastName as FullName from Customer


-------------------------------------------------------------------------------------
**Third**

Select * from Customer Where FaxNumber IS Not Null


-------------------------------------------------------------------------------------
**Fourth**

Select * from Customer Where FirstName Like '_U%'

-------------------------------------------------------------------------------------
**Fifth**

Select *
From Orderr
Left Outer Join
OrderItem 
On Orderr.id = OrderItem.Orderid
Where UnitPrice BETWEEN 10 AND 20 

------------------------------------------------------------------------------------
**Sixth**

Select * from Orderr 
Where ShippingDate IS NOT NULL 
Order By OrderDate

-------------------------------------------------------------------------------------
**Seventh**

Select id, OrderNumber FROM Orderr 
Where ShipName = 'La corned ' AND 
		OrderDate BETWEEN 1/1/2020 AND 31/12/2020

---------------------------------------------------------------------------------------
**Eight**

Select id, ProductName 
From Product 
Where Supplier = 'Exotic Liquids'

---------------------------------------------------------------------------------------
**Nineth**

Select AVG(Quantity) as AvgQuantity 
From Product 
     Right Outer Join
	 OrderItem
	 On Product.id = OrderItem.Productid

-----------------------------------------------------------------------------------------
**Eleventh**

Select EmployeeName , ManagerName 
	 From Employee 

--------------------------------------------------------------------------------------------
**Twelfth**
FROM bill
	 Left Outer Join
	 Order 
---------------------------------------------------------------------------------------------	 

**Thirteen**

Select  TotalPrice 
From Orders 
Where Supplier = 'Exotic Liquids' AND TotalPrice > 50 


----------------------------------------------------------------------------------------------

