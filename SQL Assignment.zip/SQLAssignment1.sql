
***6th, 7th***

Select Country from Customer
Where Country Like 'I%' OR Country Like 'A%'

-------------------------------------------------
Select *  from Customer 
Where LastName Like '__i%'



































