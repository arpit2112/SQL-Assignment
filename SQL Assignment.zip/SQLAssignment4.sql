**First**

Select TotalAmount, Company
From Orderr 
Where Supplier = 'Exotic Liquids' AND TotalAmount > 50 

---------------------------------------------------------------------------
**Second**

Select EmpName 
From Employee 
Where JoiningDate = (Select MIN(JoiningDate)
					 From Employee)
---------------------------------------------------------------------------
**Third**

Select * From Employee 
Where JoiningDate > 1/1/2022

---------------------------------------------------------------------------
**Fourth**

Select ProductName , O.UnitPrice
From OrderItem O FULL OUTER JOIN Product P
Where O.UnitPrice = MAX(O.UnitPrice) OR O.UnitPrice= MIN(O.UnitPrice)

-------------------------------------------------------------------------------
**Fifth**

Select ProductName,id
From Orderr
Where UnitStock < UnitOrder 
-------------------------------------------------------------------------------

**Sixth**
Select O.id, O.OrderDate, C.FirstName
From Customer as C RIGHT OUTER JOIN Orderr as O

-------------------------------------------------------------------------------
**Seventh**

Select id,COUNT(*)  as Count
From Orderr
Group By id
Order By COUNT(*) DESC

------------------------------------------------------------------------------
**Eighth**

Select id
From Customer
Where FirstName Like %RA& OR LastName Like %RA%

------------------------------------------------------------------------------
**Nineth**

Select SUBSTR(CompanyName,1,(LOCATE(' ',CompanyName)))  AS FirstWord 
From Company;