Use mydatabase

**First**

Select O.id, O.OrderNumber
From Orderr as O
	 Left Outer Join
	 Customer as C
on Orderr.Customerid = Customer.id
Where Phone = 030-0074321

------------------------------------------------------------------------------------
**Second**

Select id,ProductName
From Product 
Where Category = 'Seafood'

------------------------------------------------------------------------------------
**Third**

Select * From Orderr
			INNER JOIN
			Customer
on Orderr.CustomerId = Customer.id
Where Customer.Country != 'London';

-----------------------------------------------------------------------------------
**Fourth**

Select * From Orderr
Where id = (Select OrderId From OrderItem INNER JOIN Product
			on OrderItem.ProductId = Product.id 
			Where ProductName = 'Chai')

----------------------------------------------------------------------------------
**Fifth**

Select EmployeeName, Rating, Department 
From Employee
Where Empid = 101 ;

